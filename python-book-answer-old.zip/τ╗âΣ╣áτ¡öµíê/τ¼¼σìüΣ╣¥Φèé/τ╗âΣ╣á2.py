def cs(n):
    if n<=2:
        return n
    else:
        return cs(n-1)+cs(n-2)

meth=eval(input("梯子共有n级台阶："))
print(cs(meth))
