#练习2
C=5
def f(a):
    a+=C
    return a
a=f(C)
b=f(a)
print(a,b)

