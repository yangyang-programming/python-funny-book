#ie40-2.py
import sqlite3
from sqlite3 import Error
def create_connection(db_file): #连接数据库
    try:
        conn = sqlite3.connect(db_file)
        return conn
    except Error as e:
        print(e)
    return None

def create_table(conn, create_table_sql):#创建表
    try:
        c = conn.cursor()
        c.execute(create_table_sql)
    except Error as e:
        print(e)

def main():
    database = "score.db"
    sql_create_student_table = """ CREATE TABLE IF NOT EXISTS student (
                                           id integer PRIMARY KEY,
                                           name text NOT NULL,
                                           email text,
                                           class text
                                        ); """
    sql_create_s_result_table = """CREATE TABLE IF NOT EXISTS s_result (
                                         id integer PRIMARY KEY,
                                         name text NOT NULL,
                                         chinese integer,
                                         math integer,
                                         english integer
                                     );"""
    conn = create_connection(database)
    if conn is not None:
        create_table(conn, sql_create_student_table)
        create_table(conn, sql_create_s_result_table)
        print("OK")
    else:
        print("无法创建数据库连接！")
    conn.close()
if __name__=="__main__":
    main()
