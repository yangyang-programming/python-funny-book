#练习1.py
class Node:
    def __init__(self, val=None):
        self.val = val
        self.nextval = None

class SLinkedList:
    def __init__(self):
        self.headval = None

    def listprint(self):
        printval = self.headval
        while printval is not None:
            print (printval.val)
            printval = printval.nextval
            
    def AtBegining(self,newdata):
        NewNode = Node(newdata)
        NewNode.nextval = self.headval
        self.headval = NewNode

    def AtEnd(self, newdata):
        NewNode = Node(newdata)
        if self.headval is None:
            self.headval = NewNode
            return
        laste = self.headval
        while(laste.nextval):
            laste = laste.nextval
        laste.nextval=NewNode

    def Inbetween(self,middle_node,newdata):
        if middle_node is None:
            print("中间结点缺失")
            return
        NewNode = Node(newdata)
        NewNode.nextval = middle_node.nextval
        middle_node.nextval = NewNode

        


LinkL1 = SLinkedList()
boy1=Node("欢欢")
boy2 = Node("乐乐")
boy3 = Node("闹闹")
LinkL1.headval = boy1
boy1.nextval = boy2
boy2.nextval = boy3
LinkL1.Inbetween(boy2,"奇奇")
LinkL1.listprint()
