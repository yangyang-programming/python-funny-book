#练习2
a=[11,23,32,675,346,1456,91]
b={}
result=[] #排序后的列表
for i in range(max(a)+1):  #按自然数顺序建立桶
    b[i]=0  #每个桶的值初始化为1
for i in a:
    b[i]+=1  #将a中数字对应的桶的值加1
for i in b:
    for j in range(b[i]):
        result.append(i)
print(result)
