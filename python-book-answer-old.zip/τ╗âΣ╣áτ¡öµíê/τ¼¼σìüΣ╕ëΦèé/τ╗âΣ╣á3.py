#练习3
s=0  #记录字母的个数
n=0  #记录数字的个数
mystr=input("请输入一串字符：")
for i in mystr:
    if i>='0' and i<='9':
        n+=1
    else:
        s+=1
print("字母共有%d个"%s)
print("数字共有%d个"%n)
