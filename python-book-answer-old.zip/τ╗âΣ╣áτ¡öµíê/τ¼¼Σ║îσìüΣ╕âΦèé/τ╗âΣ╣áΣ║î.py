import turtle as tr
tr.color('black','red')
tr.begin_fill()
tr.left(140)
tr.forward(111.65)
for i in range(200):
    tr.right(1)
    tr.forward(1)
tr.left(120)
for i in range(200):
    tr.right(1)
    tr.forward(1)
tr.forward(111.65)
tr.end_fill()

