import jieba
s="每天叫醒的不是闹钟,是伟大的梦想"
result=jieba.lcut_for_search(s)
print(result)
