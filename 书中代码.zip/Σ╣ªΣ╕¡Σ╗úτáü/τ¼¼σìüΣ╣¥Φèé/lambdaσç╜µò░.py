plus = lambda x: x + 100
print(plus(10))
