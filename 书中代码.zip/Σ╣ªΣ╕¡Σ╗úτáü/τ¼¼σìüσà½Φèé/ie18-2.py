#实例18-2
def aout():
    a=10
    print("我是函数里的a，我的值是{}".format(a))

a=20
aout()
print("我是主函数里的a，我的值是{}".format(a))
