#实例17-2 完善
def check_trigle(a,b,c):
    if (a+b)>c and (b+c)>a and (a+c>b):
        print("{0}、{1}、{2}可以组成三角形".format(a,b,c))
    else:
        print("{0}、{1}、{2}无法组成三角形".format(a,b,c))

def myinput():
    n=0
    while(n<=0):
        try:
            n=eval(input("请输入一条边长："))
        except:
            pass
    return n
   
x=myinput()
y=myinput()
z=myinput()
check_trigle(x,y,z)
