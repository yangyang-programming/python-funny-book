#实例20-2
ans=0
year=eval(input("请输入年份："))
month=eval(input("请输入月份："))
day=eval(input("请输入日期："))
mday=[31,28,31,30,31,30,31,31,30,31,30,31]
for i in range(month-1):
    ans+=mday[i]
ans+=day
if month>2 and (year%400==0 or year%4==0 and year%100!=0):
    ans+=1
print("该天是这一年的第{}天。".format(ans))
    
