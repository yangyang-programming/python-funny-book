#实例20-1
a=[0,1,2]
for i in range(4,20):
    a.append(a[-2]+a[-1])
print(sorted(a,reverse=True))
