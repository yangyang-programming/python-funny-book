#练习2.py
myname="tom"
myage=12
print("My name is Tom. I am 12.")
name=input("what is your name?")
age=eval(input("how old are you?"))
if age>12:
    print("You are my older brother.")
elif age==12:
    print("We are the same age.")
else:
    print("You are my younger brother.")
