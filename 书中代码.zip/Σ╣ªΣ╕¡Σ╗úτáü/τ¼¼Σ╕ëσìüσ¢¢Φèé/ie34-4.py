#ie34-4.py
import networkx as nx
import matplotlib.pyplot as plt
g=nx.Graph()
g.add_edges_from([("L","LB"), ("L","LM"), ("LB","LM"), ("L","P"), ("L","H"), ("H","HB"), ("H","HM"), ("HM","P"), ("HB","HM"), ("HB","LB"), ("H","P")])
nx.draw(g,with_labels=True)
plt.show()
