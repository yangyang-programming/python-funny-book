#ie34-1.py
import networkx as nx
import matplotlib.pyplot as plt
g=nx.Graph()
g.add_node("A")
g.add_nodes_from(["B","C"])
g.add_nodes_from([("D",{"id":1,"age":10}),("E",{"id":2,"age":10})])
nx.draw(g,with_labels=True)
plt.show()
