#实例21-2
mydate=input("请输入日期（2000-1-1）：")
datetemp=mydate.split("-")  #将日期转换为列表
yearday=(365,366)  #记录平年和闰年的天数
p_monthday=(31,28,31,30,31,30,31,31,30,31,30,31)#记录平年每个月的天数
r_monthday=(31,29,31,30,31,30,31,31,30,31,30,31)#记录闰年每个月的天数
week=("星期日","星期一","星期二","星期三","星期四","星期五","星期六")
sumday=0   #记录总天数
for i in range(2000,int(datetemp[0])):#从2000年到输入年份前一年，计算一共多少天
    if i%400==0 or (i%4==0 and i%100!=0):#判断是不是闰年
        sumday+=yearday[1]
    else:
        sumday+=yearday[0]

if int(datetemp[1])<3:  #如果输入日期的月份小于3，就不需要再考虑这一年是否是闰年
    for i in range(int(datetemp[1])-1):
        sumday=sumday+p_monthday[i]
    
else:#如果月份大于2，要考虑是否是闰年
    for i in range(int(datetemp[1])-1):
        if int(datetemp[0])%400==0 or (int(datetemp[0])%4==0 and int(datetemp[0])%100!=0):#判断是不是闰年
            sumday+=r_monthday[i]
        else:
            sumday+=p_monthday[i]
sumday=sumday+int(datetemp[2])-1#计算到2000年1月1日的天数，注意要减去1天

weekday=(sumday%7+6)%7 #计算是星期几
print(week[weekday])

        
    
