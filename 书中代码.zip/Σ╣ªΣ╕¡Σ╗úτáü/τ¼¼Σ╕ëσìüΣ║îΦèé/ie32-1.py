#ie32-1.py
class Stack:
    def __init__(self):
        self.stack = []

    def add(self, val):
        if val not in self.stack:
            self.stack.append(val)
            return True
        else:
            return False
      
    def remove(self):
        if len(self.stack) <= 0:
            return ("空栈")
        else:
            return self.stack.pop()

AStack = Stack()
AStack.add("1")
AStack.add("2")
AStack.add("3")
AStack.add("4")
AStack.add("3")
for i in AStack.stack:
    print(i)
print("pop元素"+AStack.remove())
print("栈变为：")
for i in AStack.stack:
    print(i)
