import turtle
turtle.setup(300,300)
turtle.home()
turtle.fillcolor("black")#填充颜色设置为黑色
turtle.begin_fill()
for i in range(4):
    turtle.forward(100)
    turtle.left(90)
turtle.end_fill()

