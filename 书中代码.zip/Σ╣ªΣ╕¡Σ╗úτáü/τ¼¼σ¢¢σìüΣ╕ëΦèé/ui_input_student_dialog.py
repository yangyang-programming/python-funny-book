# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'input_student_dialog.ui'
#
# Created by: PyQt5 UI code generator 5.12.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(230, 216)
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(30, 30, 41, 16))
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(30, 60, 41, 16))
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(Dialog)
        self.label_3.setGeometry(QtCore.QRect(30, 90, 41, 16))
        self.label_3.setObjectName("label_3")
        self.label_4 = QtWidgets.QLabel(Dialog)
        self.label_4.setGeometry(QtCore.QRect(30, 120, 41, 16))
        self.label_4.setObjectName("label_4")
        self.label_5 = QtWidgets.QLabel(Dialog)
        self.label_5.setGeometry(QtCore.QRect(30, 150, 41, 16))
        self.label_5.setObjectName("label_5")
        self.nameEdit = QtWidgets.QLineEdit(Dialog)
        self.nameEdit.setGeometry(QtCore.QRect(90, 30, 113, 21))
        self.nameEdit.setObjectName("nameEdit")
        self.sexEdit = QtWidgets.QLineEdit(Dialog)
        self.sexEdit.setGeometry(QtCore.QRect(90, 60, 113, 21))
        self.sexEdit.setObjectName("sexEdit")
        self.numEdit = QtWidgets.QLineEdit(Dialog)
        self.numEdit.setGeometry(QtCore.QRect(90, 90, 113, 21))
        self.numEdit.setObjectName("numEdit")
        self.gradeEdit = QtWidgets.QLineEdit(Dialog)
        self.gradeEdit.setGeometry(QtCore.QRect(90, 120, 113, 21))
        self.gradeEdit.setObjectName("gradeEdit")
        self.classEdit = QtWidgets.QLineEdit(Dialog)
        self.classEdit.setGeometry(QtCore.QRect(90, 150, 113, 21))
        self.classEdit.setObjectName("classEdit")
        self.resetButton = QtWidgets.QPushButton(Dialog)
        self.resetButton.setGeometry(QtCore.QRect(20, 180, 81, 31))
        self.resetButton.setObjectName("resetButton")
        self.addButton = QtWidgets.QPushButton(Dialog)
        self.addButton.setGeometry(QtCore.QRect(130, 180, 81, 31))
        self.addButton.setObjectName("addButton")

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
        self.label.setText(_translate("Dialog", "姓名"))
        self.label_2.setText(_translate("Dialog", "性别"))
        self.label_3.setText(_translate("Dialog", "学号"))
        self.label_4.setText(_translate("Dialog", "年级"))
        self.label_5.setText(_translate("Dialog", "班级"))
        self.resetButton.setText(_translate("Dialog", "重置"))
        self.addButton.setText(_translate("Dialog", "添加"))


