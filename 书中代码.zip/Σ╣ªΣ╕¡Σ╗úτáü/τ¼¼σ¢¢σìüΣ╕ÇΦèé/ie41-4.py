#ie41-4.py
import sqlite3
from sqlite3 import Error

def create_connection(db_file):
    try:
        conn = sqlite3.connect(db_file)
        return conn
    except Error as e:
        print(e)
    return None

def select_all_student(conn):
    cur = conn.cursor()
    cur.execute("SELECT * FROM student")
    rows = cur.fetchall()
    for row in rows:
        print(row)
    
def insert_student(conn,s):
    sql_insert="""INSERT OR IGNORE INTO student VALUES(?,?,?,?)"""
    cur=conn.cursor()
    cur.execute(sql_insert,s)
    conn.commit()
    print("INSERT OK")


def delete_student(conn,s):
    sql_delete="""DELETE FROM student WHERE id=?"""
    cur=conn.cursor()
    cur.execute(sql_delete,(s,))
    conn.commit()
    print("DELETE OK")

def update_student(conn,s):
    sql_update="""UPDATE student SET id=?,name=?,email=?,class=? WHERE id=?"""
    cur=conn.cursor()
    cur.execute(sql_update,s)
    conn.commit()
    print("UPDATE OK")
    
def main():
    database = "score.db"
    conn = create_connection(database)
    s1=(3,"笨笨","128@A.com","3-1")
    s2=(4,"跳跳","121@A.com","3-1")
    insert_student(conn,s1)
    insert_student(conn,s2)
    select_all_student(conn)
    s=4
    delete_student(conn,s)
    newid=(3,"跳跳","121@A.com","3-1",3)
    select_all_student(conn)
    update_student(conn,newid)
    select_all_student(conn)
    conn.close()


if __name__ == '__main__':
    main()
