#练习2
a=5
b=34
print("%%%d"%a)
print("%02d"%a)
print("%d+%d=%d"%(a,b,a+b))
