print("#"*10)
print("#"+" "*8+"#")
print("#"+" "*8+"#")
print("#"*10)
