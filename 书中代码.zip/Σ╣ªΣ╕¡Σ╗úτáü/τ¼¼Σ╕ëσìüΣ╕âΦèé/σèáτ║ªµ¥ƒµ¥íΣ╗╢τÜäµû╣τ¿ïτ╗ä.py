for b in range(0, 20):
    for a in range(0, 33):
        if (a == 22):
                continue
        c = 100 - a - b
        if (c%3 == 0 && b * 5 + a * 3 + c / 3 == 100):
            print(“a = ” + a + “; b = ” + b + “; c = ” + c)
