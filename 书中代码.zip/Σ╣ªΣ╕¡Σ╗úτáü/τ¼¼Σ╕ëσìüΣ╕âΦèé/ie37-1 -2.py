#ie37-1-2.py
for a in range(0, 34):
    for b in range(0, 20):
        c = 100 - a - b
        if ( c / 3 + a * 3 + b * 5 == 100):
            print("a =" + str(a) +"; b =" +str(b) +"; c =" + str(c))
