#实例25-2
f=open("成绩.csv","r")
mydate=[]
for row in f:
    mydate.append(row.strip("\n").split(","))
f.close()

for i in mydate[1:]:
    sum_s=int(i[2])+int(i[3])+int(i[4])
    ave_s=sum_s/3.0
    print("{}的总成绩是：{}，平均成绩是：{:.1f}".format(i[0],sum_s,ave_s))
    
