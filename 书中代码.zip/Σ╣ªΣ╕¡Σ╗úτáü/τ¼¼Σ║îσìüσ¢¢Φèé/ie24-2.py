#实例24-2

#画投票界面
def draw_ui(): 
    print("******************************************************")
    print("***              请选择你喜欢的歌手                ***")
    print("***                   1、王小明                    ***")
    print("***                   2、张小乐                    ***")
    print("***                   3、张小胖                    ***")
    print("***                   4、李大牙                    ***")
    print("***                   5、宋大神                    ***")
    print("***                   6、退  出                    ***")
    print("******************************************************")

 #投票输入选手编号    
def input_num(): 
    a=0
    while(a<1 or a>6):
        try:
            a=eval(input("请输入歌手编号（6为退出）："))
        except:
            pass
    return a



choice_dict={"王小明":0,"张小乐":0,"张小胖":0,"李大牙":0,"宋大神":0}
num_int=0  #记录票投给了哪个选手的编号
while(num_int!=6):
    draw_ui()
    num_int=input_num()
    if num_int==1:
        choice_dict["王小明"]=choice_dict["王小明"]+1
    elif num_int==2:
        choice_dict["张小乐"]=choice_dict["张小乐"]+1
    elif num_int==3:
        choice_dict["张小胖"]=choice_dict["张小胖"]+1
    elif num_int==4:
        choice_dict["李大牙"]=choice_dict["李大牙"]+1
    elif num_int==5:
        choice_dict["宋大神"]=choice_dict["宋大神"]+1
print("投票结果为：")
for i in choice_dict:  #输出投票结果
    print("{}：{}票".format(i,choice_dict[i]))
b=sorted(choice_dict.items(),key=lambda x:x[1],reverse=True) #对choice_dict按值进行排序
print("得票最高的选手是：{}".format(b[0][0]))


