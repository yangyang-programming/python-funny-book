#实例7-1
a=None
while(type(a)!=int):
    try:
        a=eval(input("请输入一个整数："))
    except:
        pass
            
