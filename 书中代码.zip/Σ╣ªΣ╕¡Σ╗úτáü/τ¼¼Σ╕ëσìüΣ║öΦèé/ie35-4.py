#ie35-4.py
def quick_sort(InputList):
    if(len(InputList)<2):
        return(InputList)
    else:
        lesslist=[]
        morelist=[]
        for i in InputList[1:]:
            if(i<InputList[0]):
                lesslist.append(i)
            else:
                morelist.append(i)
    return(quick_sort(morelist)+[InputList[0]]+quick_sort(lesslist))

mysort=[5,1,3,2,6]
print(quick_sort(mysort)) 
