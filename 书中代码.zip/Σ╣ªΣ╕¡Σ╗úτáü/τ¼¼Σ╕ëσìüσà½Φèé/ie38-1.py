#38-1.py
money=eval(input())
result={}
result["20"]=money//20
result["10"]=(money%20)//10
result["5"]=(money-result["20"]*20-result["10"]*10)//5
result["1"]=(money-result["20"]*20-result["10"]*10)%5
page=0
for i in result:
    page+=result[i]
    if result[i]!=0:
        print("换{}元{}张".format(i,result[i]))
print("总共{}张纸币".format(page))
