#!/usr/bin/python

f = open("code.txt","w")
for i in range(10):
     f.write("这是第%d行\r\n" % (i+1))
f.close()

