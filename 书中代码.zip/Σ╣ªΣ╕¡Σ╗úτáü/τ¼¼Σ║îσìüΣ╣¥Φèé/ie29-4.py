#!/usr/bin/python

f = open("code.txt", "r")
if f.mode == 'r':
    contents = f.read(3)
    print(contents)
