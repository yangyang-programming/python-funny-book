import shutil
shutil.move('dir_1/', 'backup/')
