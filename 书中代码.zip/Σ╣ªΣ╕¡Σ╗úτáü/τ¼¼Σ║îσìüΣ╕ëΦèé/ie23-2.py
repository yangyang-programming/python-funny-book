#实例23-2
nums=[1,2,3,4,5,5,6,7,8,9,10,11,12]
pout=[0,0]
all_set=set(range(1,len(nums)+1))
nums_set=set(nums)
for i in all_set-nums_set:
    pout[1]=i
pout[0]=pout[1]-(sum(all_set)-sum(nums))
print(pout)
