#实例20-3 改进
a=[]
indexnum=[0]
c=0
num=eval(input("请输入数字个数："))
for i in range(num):
    a.append(eval(input("输入数字：")))
b=max(a)
c=a.count(b)
for i in range(c):
    indexnum.append(indexnum[-1]+(a[indexnum[-1]:].index(b)+1))
print("输入的数字是",a)
for i in indexnum[1:]:
    print("最大的数字为{},是第{}个数字".format(max(a),i))
