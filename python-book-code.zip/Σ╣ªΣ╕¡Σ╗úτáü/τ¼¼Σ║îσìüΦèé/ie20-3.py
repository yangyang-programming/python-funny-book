#实例20-3
a=[]
num=eval(input("请输入数字个数："))
for i in range(num):
    a.append(eval(input("输入数字：")))
b=max(a)
print("输入的数字是",a)
print("最大的数字为{},是第{}个数字".format(max(a),a.index(b)+1))
