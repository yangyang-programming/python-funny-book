import turtle
turtle.setup(300,300)
for i in range(5):
    turtle.forward(100)
    turtle.right(144)
turtle.write("OK")


