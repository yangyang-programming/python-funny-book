import turtle
turtle.setup(300,300)
turtle.bgcolor("green")
turtle.home()

