import turtle
turtle.setup(300,300)
turtle.home()
#方法一
#for i in range(3):
#    turtle.forward(80)
#    turtle.left(120)
#方法二
turtle.circle(50,steps=3)

