#一维数据的读取
csv_file=open("space.csv","r")
csv_str=csv_file.read()
mydate=csv_str.strip("\n").split(",")
print(mydate)
csv_file.close()
