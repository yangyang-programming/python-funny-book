f = open("code.txt", "r")
f1 = f.readlines()
for x in f1:
    print(x)
f.close()
