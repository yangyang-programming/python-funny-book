#实例17-2
def check_trigle(a,b,c):
    if (a+b)>c and (b+c)>a and (a+c>b):
        print("{0}、{1}、{2}可以组成三角形".format(a,b,c))
    else:
        print("{0}、{1}、{2}无法组成三角形".format(a,b,c))
x=0
y=0
z=0
while(x<=0):
    try:
        x=eval(input("请输入一条边长："))
    except:
        pass
while(y<=0):
    try:
        y=eval(input("请输入一条边长："))
    except:
        pass
while(z<=0):
    try:
        z=eval(input("请输入一条边长："))
    except:
        pass
check_trigle(x,y,z)
