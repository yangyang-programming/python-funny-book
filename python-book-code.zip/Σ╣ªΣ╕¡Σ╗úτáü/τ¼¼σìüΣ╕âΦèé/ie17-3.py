#实例17-3
import time
def nowdate():
    localtime = time.localtime(time.time())
    year=localtime.tm_year
    month=localtime.tm_mon
    day=localtime.tm_mday
    hour=localtime.tm_hour
    mini=localtime.tm_min
    sece=localtime.tm_sec
    return year,month,day,hour,mini,sece
print("当前日期和时间为:")
y,m,d,h,mi,se=nowdate()
print("{}年{}月{}日{}时{}分{}秒".format(y,m,d,h,mi,se))
