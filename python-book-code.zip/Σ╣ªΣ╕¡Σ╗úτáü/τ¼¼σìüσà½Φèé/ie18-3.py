#实例18-3
def f():
    n=0
    print("函数内，n={}".format(n))

f()
print("********************")
print("函数外，n={}".format(n))
