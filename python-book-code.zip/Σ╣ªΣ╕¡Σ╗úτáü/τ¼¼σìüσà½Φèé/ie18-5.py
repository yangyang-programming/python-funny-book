#实例18-5
VNUM=35
def f():
    VNUM=50
    print("函数内，{}".format(VNUM))


f()
print("函数外，{}".format(VNUM))
