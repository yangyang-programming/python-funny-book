#实例18-1
def check_trigle(x,y,z):
    if (x+y)>z and (y+z)>x and (x+z>y):
        return 1
    else:
        return 0
        
def myinput():
    n=0
    while(n<=0):
        try:
            n=eval(input("请输入一条边长："))
        except:
            pass
    return n

x=myinput()
y=myinput()
z=myinput()
s=1
scant=check_trigle(x,y,z)
if scant:
    p=(x+y+z)/2
    s=(p*(p-x)*(p-y)*(p-z))**(1/2)
    print("边长{}、{}、{}组成三角形的面积为：{}".format(x,y,z,s))
else:
    print("无法组成三角形！")
