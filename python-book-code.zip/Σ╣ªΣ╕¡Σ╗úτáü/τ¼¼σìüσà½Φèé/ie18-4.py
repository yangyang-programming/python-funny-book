#实例18-4
VNUM=35
def f():
    print("函数内，{}".format(VNUM))

f()
print("函数外，{}".format(VNUM))
