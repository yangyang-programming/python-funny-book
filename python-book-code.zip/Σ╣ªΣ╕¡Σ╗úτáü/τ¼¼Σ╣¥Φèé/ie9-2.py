#实例9-2
mynum=input("请输入一个三位数：")
b,s,g=mynum
newnum=int(g)*100+int(s)*10+int(b)
print("转化后的数字为：{}".format(newnum))
