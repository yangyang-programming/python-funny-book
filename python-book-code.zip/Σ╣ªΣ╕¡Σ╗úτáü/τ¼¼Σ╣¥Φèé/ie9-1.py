#实例9-1
mystr=input("请输入一个字符串：")
print("{0}+{0}+{0}+{0}+{0}".format(mystr))
