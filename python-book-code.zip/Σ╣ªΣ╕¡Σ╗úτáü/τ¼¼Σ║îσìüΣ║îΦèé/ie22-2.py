#实例22-2
mystr=input("请输入一句英文，单词间用空格间隔：")
mytab=mystr.split(" ")  #转换成单词列表
result=sorted(mytab,key=lambda i:len(i),reverse=True)#将单词列表按长度降序排列
print("{} {}".format(result[0],len(result[0])))

