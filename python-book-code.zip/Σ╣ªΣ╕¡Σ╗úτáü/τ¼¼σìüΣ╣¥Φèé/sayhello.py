def say_hello(x):
    print("你好 " + x)

say_hello("欢欢")
say_hello("乐乐")
