import sayhello
sayhello.say_hello
