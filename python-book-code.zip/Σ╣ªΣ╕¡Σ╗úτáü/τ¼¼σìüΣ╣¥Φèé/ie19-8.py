#ie19-8.py
def f(n):
    if n==1:
        return 1
    else:
        return n+f(n-1)

print(f(10))
