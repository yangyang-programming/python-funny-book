#实例16-3
#定义成绩转换为等级的函数
def grade(score):
    if score>=90:
        print("A")
    elif score>=80 and score<90:
        print("B")
    elif score>=70 and score<80:
        print("C")
    elif score>=60 and score<70:
        print("D")
    else:
        print("E")
#输入学生成绩
for i in range(1,11):
    stu_score=101
    while(stu_score>100 or stu_score<0):
        try:
            stu_score=eval(input("请输入第{}个学生数学成绩：".format(i)))
        except:
            pass
    grade(stu_score)
