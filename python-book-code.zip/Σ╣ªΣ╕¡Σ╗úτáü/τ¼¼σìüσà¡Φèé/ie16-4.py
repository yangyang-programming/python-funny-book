#实例16-4
def factorial(n):
    m=1
    for i in range(1,n+1):
        m*=i
    return m
mynum=0
while(mynum<=0):
    try:
        mynum=eval(input("请输入一个大于0的整数:"))
    except:
        pass
result=factorial(mynum)
print("{}的阶乘为:{}".format(mynum,result))
