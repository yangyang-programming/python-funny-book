#ie12-1-2.py
a=eval(input("第一个整数："))
b=eval(input("第二个整数："))
if (a>b):
    print("最大整数是：%d" %a)
else:
    print("最大整数是：%d" %b)
