#ie41-2-2.py
import sqlite3
from sqlite3 import Error

def create_connection(db_file):
    try:
        conn = sqlite3.connect(db_file)
        return conn
    except Error as e:
        print(e)
    return None

def select_all_student(conn):
    cur = conn.cursor()
    cur.execute("SELECT * FROM student")
    rows = cur.fetchall()
    for row in rows:
        print(row)
    
def insert_student(conn,s):
    sql_insert="""INSERT OR IGNORE INTO student VALUES(?,?,?,?)"""
    cur=conn.cursor()
    cur.execute(sql_insert,s)
    conn.commit()
    print("INSERT OK")

def main():
    database = "score.db"

    conn = create_connection(database)
    s1=(1,"欢欢","125@A.com","3-1")
    s2=(2,"乐乐","127@A.com","3-1")
    insert_student(conn,s1)
    insert_student(conn,s2)
    if conn is not None:
        select_all_student(conn)
    conn.close()

if __name__ == '__main__':
    main()
