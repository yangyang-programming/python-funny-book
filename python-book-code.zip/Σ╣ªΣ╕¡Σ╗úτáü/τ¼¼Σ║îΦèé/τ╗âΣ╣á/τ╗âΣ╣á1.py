#练习1.py
a=5
b=6
print(str(a)+'+'+str(b)+'='+str(a+b))
