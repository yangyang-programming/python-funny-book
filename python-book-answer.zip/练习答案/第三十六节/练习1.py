#练习1.py
def insert_sort(ret, num):
    idx0 = 0  # 索引起点
    idxn = len(ret)-1  # 索引终点
    while idx0 < idxn:  # 起点索引大于或等于列表最后一个元素的索引，条件无法进入。
        mid = (idx0 + idxn) // 2  # 取列表中间点的索引
        if num < ret[mid]:  #  条件判断，如果待插入列表的值小于有序列表对应mid索引的值，就向左查询，
            idxn = mid  # 同时确认这个中间点mid索引就是ret列表的idxn最高索引，然后继续用二分法。
        else:  # 如果待插入列表的值大于有序列表对应mid索引的值，就向右查询，求中点
            idx0 = mid + 1  # 同时确认这个中间点mid索引就是ret列表的开始索引idx0的值。
    return idx0 # 最终计算出来的待插入索引的位置



myarr = [12,34,5,67,23,89,36,21]
insert_s = [20,30,50]
order_list = sorted(myarr)
print(order_list)
ret = order_list[:]  
for num in insert_s:  
    index = insert_sort(ret, num)  # 调用上面的函数取出插入元素索引值。
    ret.insert(index, num)  # 就地插入对应索引的值到列表ret中.
print(ret) 
