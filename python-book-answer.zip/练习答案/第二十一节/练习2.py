#练习2
meat=("西红柿炒鸡蛋","大虾面","黄瓜炒肉","尖椒牛柳","水饺","休息","休息")
weekday=8
while(weekday<1 or weekday>7):
    try:
        weekday=eval(input("星期（如果是星期日请填7）："))
    except:
        pass
print("这天是{}".format(meat[weekday-1]))
