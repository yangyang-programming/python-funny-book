#练习1.py
import sqlite3
from sqlite3 import Error

def create_connection(db_file):
    try:
        conn = sqlite3.connect(db_file)
        return conn
    except Error as e:
        print(e)
    return None

def select_all_s_result(conn):
    cur = conn.cursor()
    cur.execute("SELECT * FROM s_result")
    rows = cur.fetchall()
    for row in rows:
        print(row)
    
def insert_s_result(conn,s):
    sql_insert="""INSERT OR IGNORE INTO s_result VALUES(?,?,?,?,?)"""
    cur=conn.cursor()
    cur.execute(sql_insert,s)
    conn.commit()
    print("INSERT OK")


def delete_s_result(conn,s):
    sql_delete="""DELETE FROM s_result WHERE id=?"""
    cur=conn.cursor()
    cur.execute(sql_delete,(s,))
    conn.commit()
    print("DELETE OK")

def update_s_result(conn,s):
    sql_update="""UPDATE s_result SET chinese=? WHERE name=?"""
    cur=conn.cursor()
    cur.execute(sql_update,s)
    conn.commit()
    print("UPDATE OK")
    
def main():
    database = "score.db"
    conn = create_connection(database)
    newid=(99,"乐乐")
    update_s_result(conn,newid)
    select_all_s_result(conn)
    conn.close()


if __name__ == '__main__':
    main()
