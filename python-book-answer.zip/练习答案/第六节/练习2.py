#练习2
y=round(500*pow((100+3)/100,7),2)

print("本利合计：{}元".format(y))
