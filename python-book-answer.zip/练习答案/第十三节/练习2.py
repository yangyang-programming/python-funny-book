#练习2
for i in range(5,1000):
    if i%3==2 and i%5==3 and i%7==5:
        print(i)
