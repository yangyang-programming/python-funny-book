#练习2.py
a=eval(input("第1条边长："))
b=eval(input("第2条边长："))
c=eval(input("第3条边长："))
if a+b>c and a+c>b and c+b>a and abs(a-b)<c and abs(a-c)<b and abs(b-c)<a:
    print("可以组成三角形")
else:
    print("无法组成三角形")
