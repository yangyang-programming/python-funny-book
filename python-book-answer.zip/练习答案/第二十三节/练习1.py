#练习1
a=input("请输入一个字符串：")
a=a.lower()
b=set(a)
for i in b:
    if i>="a" and i<="z":
        print("{}:{}".format(i,a.count(i)))
