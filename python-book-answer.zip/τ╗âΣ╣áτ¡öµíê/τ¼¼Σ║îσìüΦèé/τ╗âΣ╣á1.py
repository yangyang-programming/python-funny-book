#练习1
a=25  #记录火柴数
sumn=0  #记录等式个数
while(a>24 or a<1):
    try:
        a=eval(input("请输入火柴数："))
    except:
        pass
matchnum=[6,2,5,5,4,5,6,3,7,6]  #每个数字对应的火柴数列表，数字就是该列表索引
for i in range(10,2000):
    k=str(i)
    temp=0
    for j in k:
        temp+=matchnum[int(j)]
    matchnum.append(temp)
for i in range(1000):  #加数
    for j in range(1000):  #被加数
        c=i+j    #得数
        if matchnum[i]+matchnum[j]+matchnum[c]==a-4:
            sumn+=1
            print("{}+{}={}".format(i,j,c))
print("等式共{}个".format(sumn))

        
