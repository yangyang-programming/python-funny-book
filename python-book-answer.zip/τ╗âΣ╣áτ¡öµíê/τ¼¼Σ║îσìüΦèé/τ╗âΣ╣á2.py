#练习2
studentstate=[0]+[1]*23  #用1表示该学生是站着，0表示是坐着,因为学生从1开始计数，所以第0个学生让他一直坐着
k=24
while(k>23 or k<1):
    try:
        k=eval(input("请输入一共几轮(1<=k<=23)："))
    except:
        pass
for i in range(2,k+1):
    j=1
    while(j<=23):
        if j%i==0:
            studentstate[j]=not studentstate[j]
        j+=1
for i in range(24):
    
    if studentstate[i]:
        print("{}".format(i),end=" ")

    
            
