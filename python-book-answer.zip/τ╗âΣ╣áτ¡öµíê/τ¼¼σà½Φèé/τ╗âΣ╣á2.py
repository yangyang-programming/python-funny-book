#练习2
num=3.14
realnum=int(num)
imagnum=int((3.14-realnum)*100)
print("新的复数为：{}".format(complex(realnum,imagnum)))
