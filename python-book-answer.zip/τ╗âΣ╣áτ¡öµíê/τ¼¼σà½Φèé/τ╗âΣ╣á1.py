#练习1
num=str(523)
b,s,g=num
print("百位："+b+" 十位："+s+" 个位："+g)
new=int(g)*100+int(b)*10+int(s)
print("新数字是："+str(new))
