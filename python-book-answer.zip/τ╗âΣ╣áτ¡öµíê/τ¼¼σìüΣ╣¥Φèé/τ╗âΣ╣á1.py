def rt(month):
    if month<=2:
        return 2
    else:
        return rt(month-1)+rt(month-2)
 
month=eval(input("请输入month："))
for i in range(0,month):
    print(rt(i),end=" ")
