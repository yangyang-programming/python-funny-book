#实例25-2
f=open("成绩.csv","r")
mydate=[]
for row in f:
    mydate.append(row.strip("\n").split(","))
f.close()
date_s=[]  #存储带总成绩和平均成绩的列表
date_s.append(mydate[0]+["总成绩","平均成绩"])
for i in mydate[1:]:
    sum_s=int(i[2])+int(i[3])+int(i[4])
    ave_s=sum_s/3.0
    i.append(str(sum_s))
    i.append("{:.1f}".format(ave_s))
    date_s.append(i)
f=open("期末成绩.csv","w")
for row in date_s:
    f.write(",".join(row)+"\n")
f.close()
    
