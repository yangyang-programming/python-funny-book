#实例25-2
f=open("期末成绩.csv","r")
mydate=[]#建立学生成绩列表
for row in f:
    mydate.append(row.strip("\n").split(","))
f.close()

mydict={}#建立字典，键是mydate里的索引号（学生的条目），值是每个索引里的总分
for i in range(1,len(mydate)):
    mydict[i]=mydate[i][-2]
enddate=sorted(mydict.items(),key=lambda x:x[1],reverse=True)  #对字典按值排序，也就是按部分排序
print("成绩从高到低排序：\n")
for i in enddate:
    for j in mydate[i[0]]:
        print(j,end=" ")
    print("\n")
    
