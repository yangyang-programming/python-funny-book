#计算阶乘
num=eval(input("请输入一个正整数："))
result=1
if num==0:
    print(str(num)+"的阶乘是0")
else:
    for i in range(num,1,-1):
        result=result*i
    print(str(num)+"的阶乘是"+str(result))
