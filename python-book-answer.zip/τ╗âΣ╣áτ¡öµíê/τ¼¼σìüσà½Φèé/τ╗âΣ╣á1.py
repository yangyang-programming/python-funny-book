#练习1
TXT="hello world!"
def f():
    global TXT
    for i in TXT:
        print(i,end=",")
    TXT="abc"

f()
print(TXT)
