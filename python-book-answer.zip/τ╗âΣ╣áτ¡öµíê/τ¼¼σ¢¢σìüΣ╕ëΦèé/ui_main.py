# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'mainwindow.ui'
#
# Created by: PyQt5 UI code generator 5.12.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(437, 331)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.inputStudent = QtWidgets.QPushButton(self.centralwidget)
        self.inputStudent.setGeometry(QtCore.QRect(50, 90, 161, 81))
        self.inputStudent.setObjectName("inputStudent")
        self.inputScore = QtWidgets.QPushButton(self.centralwidget)
        self.inputScore.setGeometry(QtCore.QRect(220, 90, 161, 81))
        self.inputScore.setObjectName("inputScore")
        self.showStudent = QtWidgets.QPushButton(self.centralwidget)
        self.showStudent.setGeometry(QtCore.QRect(50, 180, 161, 81))
        self.showStudent.setObjectName("showStudent")
        self.showScore = QtWidgets.QPushButton(self.centralwidget)
        self.showScore.setGeometry(QtCore.QRect(220, 180, 161, 81))
        self.showScore.setObjectName("showScore")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(150, 20, 131, 31))
        self.label.setObjectName("label")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 437, 22))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.inputStudent.setText(_translate("MainWindow", "输入学生"))
        self.inputScore.setText(_translate("MainWindow", "输入成绩"))
        self.showStudent.setText(_translate("MainWindow", "显示学生"))
        self.showScore.setText(_translate("MainWindow", "显示成绩"))
        self.label.setText(_translate("MainWindow", "学生成绩统计系统"))


