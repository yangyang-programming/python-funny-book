#练习1.py
a=eval(input("请输入一个整数："))
if a<=7:
    print("%d 既不是3的倍数也不是7的倍数" %a)
elif a%3==0 and a%7==0:
    print("%d 既是3的倍数也是7的倍数" %a)
else:
    print("%d 既不是3的倍数也不是7的倍数" %a)
