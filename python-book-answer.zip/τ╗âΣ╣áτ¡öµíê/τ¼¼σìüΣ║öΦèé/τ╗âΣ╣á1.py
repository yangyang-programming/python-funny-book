#练习1
import random
gamenum=random.randint(1,10000) #生成一个1-10000之间的随机数，让用户来猜
count=0  #记录猜的次数
getnum=0 #用户猜的数
while(getnum!=gamenum):
    try:
        getnum=eval(input("请输入一个1-10000之间的数："))
    except:
        print("输入错误！")
        continue
    if getnum<gamenum:
        print("猜小了")
    if getnum>gamenum:
        print("猜大了")
    count+=1
print("BINGO!")
print("您共猜了%d次"%count)
        

    
            
