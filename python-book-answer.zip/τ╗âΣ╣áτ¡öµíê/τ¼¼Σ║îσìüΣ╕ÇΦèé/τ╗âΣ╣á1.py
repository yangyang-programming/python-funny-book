#练习1
p_monthday=(31,28,31,30,31,30,31,31,30,31,30,31)
r_monthday=(31,29,31,30,31,30,31,31,30,31,30,31)
date_in=input("请输入一个日期（格式：2000-1-1）：")
mydate=date_in.split("-")
sumday=0
year=int(mydate[0])
month=int(mydate[1])
day=int(mydate[2])
if month<3:
    for i in range(month-1):
        sumday+=p_monthday[i]
else:
    for i in range(month-1):
        if year%400==0 or (year%4==0 and year%100!=0):
            sumday+=r_monthday[i]
        else:
            sumday+=p_monthday[i]
sumday+=day
print("这是这一年的第{}天".format(sumday))
