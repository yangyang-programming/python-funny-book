a=[]
for i in range(5):
    a.append(eval(input()))
f=open("max.log","a")
f.write(str(max(a)))
f.close()
