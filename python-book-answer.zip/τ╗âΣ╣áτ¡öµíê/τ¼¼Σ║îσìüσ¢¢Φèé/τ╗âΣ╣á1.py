#练习1
a=[11,23,32,675,346,1456,91]
b={}
b=b.fromkeys(a,0)
for i in b:
    b[i]=str(i)
c=sorted(b.items(),key=lambda x:x[1])
d=[]
for i in c:
    d.append(i[0])
print(d)
