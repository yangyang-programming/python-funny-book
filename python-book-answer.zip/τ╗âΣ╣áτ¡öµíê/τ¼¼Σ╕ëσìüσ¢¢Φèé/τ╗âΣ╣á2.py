#练习2.py
import networkx as nx
g=nx.Graph()
g.add_node("B")
g.add_edges_from([("A","F"), ("F","C"), ("D","E")])

print("顶点的度：",end="")
print(g.degree)
