#练习1.py
import networkx as nx
import matplotlib.pyplot as plt
g=nx.Graph()
g.add_node("B")
g.add_edges_from([("A","F"), ("F","C"), ("D","E")])
nx.draw(g,with_labels=True)
plt.show()
