#练习2.py
class Queue:
    def __init__(self):
        self.queue = list()

    def addtoq(self,val):
        if val not in self.queue:
            self.queue.insert(0,val)
            return True
        return False

    def size(self):
        return len(self.queue)

    def removefromq(self):
        if len(self.queue)>0:
            return self.queue.pop()
        return ("队列中没有元素！")

MyQueue = Queue()
MyQueue.addtoq("Tom")
MyQueue.addtoq("Peter")
MyQueue.addtoq("Mandy")
MyQueue.addtoq("Lili")
MyQueue.addtoq("jone")
for i in MyQueue.queue:
    print(i)
print("队列出队："+MyQueue.removefromq())
