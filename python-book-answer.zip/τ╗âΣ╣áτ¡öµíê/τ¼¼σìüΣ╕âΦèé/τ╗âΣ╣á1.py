#练习1
def makebook(lastm,book6):
    if lastm==0:
        print("6元书共{}本，13元书共{}本，15元书共{}本，20元书共{}本。".format(book6,0,0,0))
    elif lastm==1:
        print("6元书共{}本，13元书共{}本，15元书共{}本，20元书共{}本。".format(book6-2,1,0,0))
    elif lastm==2:
        print("6元书共{}本，13元书共{}本，15元书共{}本，20元书共{}本。".format(book6-3,0,0,1))
    elif lastm==3:
        print("6元书共{}本，13元书共{}本，15元书共{}本，20元书共{}本。".format(book6-2,0,1,0))
    elif lastm==4:
        print("6元书共{}本，13元书共{}本，15元书共{}本，20元书共{}本。".format(book6-4,1,1,0))
    else:
        print("6元书共{}本，13元书共{}本，15元书共{}本，20元书共{}本。".format(book6-5,0,1,1))
mymoney=34
while(mymoney<35):
    try:
        mymoney=eval(input("请输入零花钱数（大于等于35的整数）："))
    except:
        pass
makebook(mymoney%6,mymoney//6)
