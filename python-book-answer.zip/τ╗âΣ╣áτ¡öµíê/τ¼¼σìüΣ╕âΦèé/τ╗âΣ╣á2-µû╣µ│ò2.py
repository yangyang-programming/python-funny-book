#练习2
def check(a,b,c):
    if a**3+b**3+c**3==a*100+b*10+c:
        return True
    else:
        return False
for i in range(1,10):
    for j in range(0,10):
        for k in range(0,10):
            if check(i,j,k):print(i*100+j*10+k)
