#练习2
def check(n):
    mystr=str(n)
    a,b,c=mystr
    if int(a)**3+int(b)**3+int(c)**3==n:
        return True
    else:
        return False
for i in range(100,1000):
    if check(i):
        print(i)
