#练习1
head=30
foot=90
chicken=0
hare=0
while(chicken<=30):
    hare=30-chicken
    if chicken*2+hare*4==90:
        print("鸡一共有%d只，兔子一共有%d只！"%(chicken,hare))
        break
    chicken+=1
