#练习2
num=None #输入的自然数
times=0 #记录经历的变化次数
while(type(num)!=type(1)):
    num=eval(input("请输入任意自然数："))
mynum=num #保存输入的数
while(num!=1):
    if num%2==0:
        num=num/2
    else:
        num=num*3+1
    times+=1
print("从%d变为1共经历了%d次变化"%(mynum,times))
