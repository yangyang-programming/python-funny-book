#练习1
man=30
product=500
num,last=divmod(500,30)
print("每个工人需要生产{}个，还剩下{}个没人生产".format(num,last))
