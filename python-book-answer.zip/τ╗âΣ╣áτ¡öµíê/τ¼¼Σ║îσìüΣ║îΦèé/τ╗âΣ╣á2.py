#练习2
a=input("请输入一名英文语句：")
for i in a:
    if i>='A' and i<='Z':
        print(i,end=" ")
        
