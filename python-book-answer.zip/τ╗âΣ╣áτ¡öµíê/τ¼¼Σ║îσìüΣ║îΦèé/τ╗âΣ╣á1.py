#练习1
n='Y'
while n.upper()=='Y':
    username=input("请输入用户名：")
    password=input("请输入密码：")
    if username=="test" and password=="test@123":
        print("成功进入")
        break
    else:
        n=input("输入错误，是否重新输入（“Y/N”）：")
