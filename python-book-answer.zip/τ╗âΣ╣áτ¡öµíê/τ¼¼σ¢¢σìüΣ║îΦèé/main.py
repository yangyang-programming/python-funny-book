# -*- coding: utf-8 -*-
import sys
from PyQt5 import QtCore, QtGui, QtWidgets
from ui import Ui_MainWindow as Ui_MainWindow

class StudentMainWindow(QtWidgets.QMainWindow, Ui_MainWindow):
    def __init__(self):
 # init UI classes
        QtWidgets.QMainWindow.__init__(self)
        Ui_MainWindow.__init__(self)
        self.setupUi(self)
 # set fixed size
        self.setFixedSize(self.size())
# set window title
        self.title = self.setWindowTitle("Login")


if __name__ == '__main__':
     app = QtWidgets.QApplication(sys.argv)
     main_window = StudentMainWindow()
     main_window.show()
     sys.exit(app.exec_())
