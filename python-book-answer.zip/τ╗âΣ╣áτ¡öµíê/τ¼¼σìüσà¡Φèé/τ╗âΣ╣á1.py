#练习1
#挂重与长度的函数关系，考虑下为什么和数学计算时表达式不一样
def f(x):
    y=2*(x-15)  #x表示长度，y表示重量
    return y
g=14
while(g<15 and g>25): #考虑下，为什么g不能大于25
    try:
        g=eval(input("请输入弹簧长度"))
    except:
        pass
h=f(g)
print("挂重为{}公斤时，弹簧长度为{}厘米".format(h,g))
25
