#练习2
#电话费与时长的函数关系
def f(x):
    y=1.06*(3/4*int(x)+7/4)  #x表示长度，y表示重量
    return y
g=-1
while(g<0):
    try:
        g=eval(input("请输入从甲城市到乙城市的电话时长："))
    except:
        pass

if g==0:
    print("未打电话，费用为0")
else:
    h=f(g)
    print("从甲城市到乙城市的电话时长{}分钟时，电话费为{}".format(g,h))
