#练习2
n=input("输入一个三位数：")
n=n*2  #字符串重复2次
n=eval(n)
newnum=n/7/11/13
print(newnum)
