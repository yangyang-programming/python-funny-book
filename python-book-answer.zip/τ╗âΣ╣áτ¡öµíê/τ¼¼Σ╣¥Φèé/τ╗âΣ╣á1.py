#练习1
a=eval(input("请输入长方形的长："))
b=eval(input("请输入长方形的宽："))
s=a*b
print("长方形面积：{}".format(s))
