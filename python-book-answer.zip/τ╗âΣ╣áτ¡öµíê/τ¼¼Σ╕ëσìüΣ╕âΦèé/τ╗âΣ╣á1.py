#练习1.py
h=eval(input("头的数量"))
f=eval(input("脚的数量"))
c=0#鸡
t=0#兔

for c in range(7):
    t=7-c
    if 2*c+4*t==f:
        print("鸡的数量："+str(c))
        print("兔子的数量："+str(t))
        break
else:
    print("无符合条件的组合")
