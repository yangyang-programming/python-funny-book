#ie35-2.py
def selection_sort(nlist):
    if(len(nlist)<2):
        return(nlist)
    else:
        minnum=min(nlist)
        nlist.remove(minnum)
        return(selection_sort(nlist)+[minnum])
    
mysort=[5,1,3,2,6]
print(selection_sort(mysort))
