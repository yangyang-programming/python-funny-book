#ie35-1.py
def bubblesort(arr):
    for iter_num in range(len(arr)):
        for idx in range(0,len(arr)-iter_num-1):
            if arr[idx]<arr[idx+1]:
                arr[idx],arr[idx+1]=arr[idx+1],arr[idx]
mysort = [5,1,3,2,6]
bubblesort(mysort)
print(mysort)
