#ie33-3.py
class Node:
    def __init__(self, data):
        self.left = None
        self.right = None
        self.data = data

    def insert(self,lorr,data):
        if self.data:
             if lorr==1:
                 if self.left is None:
                     self.left = Node(data)
                 else:
                     self.left.insert(1,data)
             else:
                 if self.right is None:
                     self.right = Node(data)
                 else:
                     self.right.insert(0,data)
        else:
             self.data = data
    def PrintTree(self):
        if self.left:
             self.left.PrintTree()
        print(self.data),
        if self.right:
             self.right.PrintTree()
        
             
root = Node("A")
root.insert(1,"B")
root.insert(0,"C")
root.left.insert(1,"D")
root.right.insert(1,"F")
root.right.insert(0,"G")
root.PrintTree()
