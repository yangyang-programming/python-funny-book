#ie33-1.py
class Node:
    def __init__(self, data):
        self.left = None
        self.right = None
        self.data = data
    def PrintTree(self):
        print(self.data)

root = Node("A")
root.PrintTree()
