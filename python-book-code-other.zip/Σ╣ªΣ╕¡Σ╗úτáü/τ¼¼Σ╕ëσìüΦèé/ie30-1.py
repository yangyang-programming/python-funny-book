#ie30-1.py
class xypoint:
    def __init__(self,xpoint,ypoint):
        self.xpoint = xpoint
        self.ypoint = ypoint

    def plusf(self,another):#坐标+
        xpoint = self.xpoint + another.xpoint
        ypoint = self.ypoint + another.ypoint
        return xypoint(xpoint, ypoint)
    def print(self):
        print(str(self.xpoint) + "," +str(self.ypoint) )

p1=xypoint(3,2)
p2=xypoint(1,5)
p3=p1.plusf(p2)
p1.print()
p2.print()
p3.print()
