#ie32-4.py
class Queue:
    def __init__(self):
        self.queue = list()

    def addtoq(self,val):
        if val not in self.queue:
            self.queue.insert(0,val)
            return True
        return False

    def size(self):
        return len(self.queue)

    def removefromq(self):
        if len(self.queue)>0:
            return self.queue.pop()
        return ("队列中没有元素！")

MyQueue = Queue()
MyQueue.addtoq("1")
MyQueue.addtoq("2")
MyQueue.addtoq("3")
MyQueue.addtoq("4")
print("队列共有元素："+str(MyQueue.size()))
print("队列出队："+MyQueue.removefromq())
print("队列共有元素："+str(MyQueue.size()))
for i in MyQueue.queue:
    print(i)
