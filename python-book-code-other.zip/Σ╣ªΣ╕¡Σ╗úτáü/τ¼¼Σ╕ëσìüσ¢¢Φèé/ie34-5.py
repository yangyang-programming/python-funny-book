#ie34-5
#任意树结构每个结点下子结点的个数以及每个结点下层级的深度
import networkx as nx
import matplotlib.pyplot as plt

#一层层结点去遍历子结点的个数
def findnum(tim):
    global m,n,jiedian,flag
    for j in edges:
        
        if tim==j[0] :
            m[i]+=n[j[1]]
            
            if n[j[1]]!=0:
                flag+=1
                findnum(j[1])#如果结点的子结点数不为0，就继续向下层找，直到找到子结点数为0的结点停止
            else:
                if flag>ji[jiedian]:
                    ji[jiedian]=flag
                flag=1


G = nx.DiGraph()
cout=[("A","B"),("A","C"),("B","D"),("B","E"),("C","F"),("C","G"),("C","H"),("D","I"),("D","J"),("G","K")]
G.add_edges_from(cout)
edges=G.edges()
degree=G.degree()

n={}#结点的度字典
for i in degree:
    n[i[0]]=i[1]-1 #因为树只有一个前继结点，所以减去1

m={}#结点下所有发展的子结点个数
jiedian=""
ji={}#记录每个结点下子结点的层级数
flag=1
  
for i in n:
    m[i]=n[i]
    jiedian=i
    ji[jiedian]=0
    findnum(i)
m["A"]+=1 #根结点因为没有前继结点，所以这里需要再把1加回来
                
print(m)
print(ji)


