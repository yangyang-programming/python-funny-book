#实例6-1
student=25
paper=48
print("每个同学可以分{}张".format(paper//student))
print("老师还剩{}张".format(paper%student))
print("如果每个同学分2张，老师还缺{}张".format(student*2-paper))
