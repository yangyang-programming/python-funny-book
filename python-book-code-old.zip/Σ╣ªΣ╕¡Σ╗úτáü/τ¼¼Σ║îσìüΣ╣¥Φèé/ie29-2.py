#!/usr/bin/python

f=open("code.txt", "a")
for i in range(2):
     f.write("附加行%d\r\n" % (i+1))
f.close()
