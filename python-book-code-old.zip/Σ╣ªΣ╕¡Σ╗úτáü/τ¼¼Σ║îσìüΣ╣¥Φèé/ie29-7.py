import  shutil 
shutil .copytree ('data_1' ,  'data1_backup' )
