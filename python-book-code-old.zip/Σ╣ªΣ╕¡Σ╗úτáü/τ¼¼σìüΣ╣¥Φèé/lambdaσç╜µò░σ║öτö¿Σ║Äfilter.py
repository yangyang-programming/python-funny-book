my_list = [1, 5, 13, 4, 6, 8, 3, 12, 20]
new_list = list(filter(lambda x: (x%2 == 0) , my_list))
print(new_list)
