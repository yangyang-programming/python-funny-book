def say_hello(x):
    print("你好 学号：" + x)

for i in range(100):
say_hello(i)
