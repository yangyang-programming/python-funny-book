#ie19-9.py
class Animal:
    def __init__(self, age, gender):
        self.age = age
        self.gender = gender

    def detail(self):
        print("我的年龄是" + str(self.age))
        print("我的性别是" + self.gender)
#实例 Dog类

class Dog(Animal):
    def __init__(self, age, gender):
        Animal.__init__(self,age, gender)
        print("我是一只狗")

#实例 Dog类的实例化
dog = Dog(3,"公")
dog.detail()
