#19-2.py
def say_hello(x):
    print("你好 " + x)
if __name__=='__main__':
    say_hello("欢欢")
    say_hello("乐乐")
