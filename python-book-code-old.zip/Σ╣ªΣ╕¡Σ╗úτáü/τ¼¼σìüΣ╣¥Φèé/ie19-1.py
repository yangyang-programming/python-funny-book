print("你好 欢欢")
print("你好 乐乐")
