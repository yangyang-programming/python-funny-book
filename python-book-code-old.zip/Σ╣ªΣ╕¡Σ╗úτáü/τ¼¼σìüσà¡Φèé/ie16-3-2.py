#实例16-3 添加计算平均分
#定义成绩转换为等级的函数
def grade(score):
    if score>=90:
        print("A")
    elif score>=80 and score<90:
        print("B")
    elif score>=70 and score<80:
        print("C")
    elif score>=60 and score<70:
        print("D")
    else:
        print("E")
def ava_score(score,n):  #计算平均分，其中score表示总分，n表示人数
    print("平均分为：{:.2f}".format(score/n))
#输入学生成绩
sum_score=0 #记录总分数
for i in range(1,11):
    stu_score=101
    while(stu_score>100 or stu_score<0):
        try:
            stu_score=eval(input("请输入第{}个学生数学成绩：".format(i)))
        except:
            pass
    sum_score+=stu_score
    grade(stu_score)
ava_score(sum_score,10)
