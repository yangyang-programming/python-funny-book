#实例14-3
n=0
while True:
    print(n)
    n+=1
