#实例9-3
dist=eval(input("两城市之间距离（km)："))
speed=eval(input("汽车平均速度（km/h）："))
avad=eval(input("每公升汽油可以行驶公里数（km）："))
price=eval(input("每公升汽油价格（元）："))
print("汽车从一座城市到另一座所花费的时间（h）：{:.2f}".format(dist/speed))
print("费用：{:.2f}".format(dist/avad*price))
