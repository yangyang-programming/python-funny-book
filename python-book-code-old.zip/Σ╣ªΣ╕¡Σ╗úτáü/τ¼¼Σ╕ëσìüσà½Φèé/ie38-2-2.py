#ie38-2-2.py
m=eval(input("大口袋能装的最大重量："))
n=eval(input("现有物品件数："))
new=[]
for i in range(n):
    ig=eval(input("第"+str(i+1)+"个物品重量："))
    ip=eval(input("第"+str(i+1)+"个物品价值："))
    new.append([i+1,ig,ip,ip/ig])#列表new中，每个元素又是列表，列表中四个元素分别是物品编号、重量、价值和单位价值
new=sorted(new,key=lambda x:x[2],reverse=True)#按每个列表中的第4项单位价值进行排序，形成新的列表new，这时new中的物品是按单位价值从大到小排列的
sum=0 #记录放入包中的物品重量
price=0 #记录放入包中的物品价值
for i in new:
    if sum+i[1]<m:
        sum+=i[1]
        price+=i[2]
        print(i)
print(price)
