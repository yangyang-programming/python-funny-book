#main.py
import sys, sqlite3
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QMessageBox
from ui_main import Ui_MainWindow as Ui_MainWindow
from ui_input_student_dialog import Ui_Dialog as Ui_InputStudentDialog
from ui_input_score_dialog import Ui_Dialog as Ui_InputScoreDialog
from ui_show_dialog import Ui_Dialog as Ui_ShowDialog

class DBHelper():
    def __init__(self):
        self.conn=sqlite3.connect("studentscore.db")
        self.c=self.conn.cursor()
        self.c.execute("CREATE TABLE IF NOT EXISTS students(name TEXT,gender TEXT,num INTEGER,grade INTEGER,classno INTEGER)")
        self.c.execute("CREATE TABLE IF NOT EXISTS score(num INTEGER,chinese INTEGER,math INTEGER,english INTEGER,sports INTEGER)")

    def add_student(self, name, gender, num, grade, classno):
        self.c.execute("INSERT INTO students (name,gender,num,grade,classno) VALUES (?,?,?,?,?)",(name, gender, num, grade, classno))
        self.conn.commit()
        self.c.close()
        self.conn.close()
        QMessageBox.information(QMessageBox(),'成功','学生信息成功添加到数据库中')

    def add_score(self, num, chinese, math, english, sports):
        self.c.execute("INSERT INTO score (num,chinese,math,english,sports) VALUES (?,?,?,?,?)",(num, chinese, math, english, sports))
        self.conn.commit()
        self.c.close()
        self.conn.close()
        QMessageBox.information(QMessageBox(),'成功','学生成绩成功添加到数据库中')

    def show_student(self):
        self.c.execute("SELECT * from students ORDER BY num DESC")
        self.list = self.c.fetchall()
        self.c.close()
        self.conn.close()

    def show_score(self):
        self.c.execute("SELECT * from students ORDER BY num DESC")
        self.list = []
        student_list = self.c.fetchall()
        for num_student in range(len(student_list)):
            self.c.execute("SELECT * from score WHERE num=?", (student_list[num_student][2],))
            score_list = self.c.fetchone()
            self.list.append(student_list[num_student] + score_list[1:])
        self.c.close()
        self.conn.close()

class StudentMainWindow(QtWidgets.QMainWindow, Ui_MainWindow):
    def __init__(self):
        # init UI classes
        QtWidgets.QMainWindow.__init__(self)
        Ui_MainWindow.__init__(self)
        self.setupUi(self)
        # set fixed size
        self.setFixedSize(self.size())
        # set window title
        self.title = self.setWindowTitle("学生成绩统计系统")
        # link objects with widgets
        self.connect_object()

    def connect_object(self):
        self.inputStudent.clicked.connect(self.input_student_window)
        self.showStudent.clicked.connect(self.show_student_window)
        self.inputScore.clicked.connect(self.input_score_window)
        self.showScore.clicked.connect(self.show_score_window)

    def input_student_window(self):
        pop_window = InputStudentWindow()
        pop_window.exec()

    def input_score_window(self):
        pop_window = InputScoreWindow()
        pop_window.exec()

    def show_student_window(self):
        pop_window = ShowStudentWindow()
        pop_window.exec()

    def show_score_window(self):
        pop_window = ShowScoreWindow()
        pop_window.exec()

class InputStudentWindow(QtWidgets.QDialog, Ui_InputStudentDialog):
    def __init__(self):
        # init UI classes
        QtWidgets.QMainWindow.__init__(self)
        Ui_InputStudentDialog.__init__(self)
        self.setupUi(self)
        # set fixed size
        self.setFixedSize(self.size())
        # set window title
        self.title = self.setWindowTitle("学生信息输入")
        # link objects with widgets
        self.connect_object()

    def connect_object(self):
        self.resetButton.clicked.connect(self.reset_dialog_text)
        self.addButton.clicked.connect(self.add_student)

    def reset_dialog_text(self):
        self.nameEdit.clear()
        self.sexEdit.clear()
        self.numEdit.clear()
        self.gradeEdit.clear()
        self.classEdit.clear()

    def add_student(self):
        name = self.nameEdit.text()
        gender = self.sexEdit.text()
        num = int(self.numEdit.text())
        grade = int(self.gradeEdit.text())
        classno = int(self.classEdit.text())
        self.dbhelper = DBHelper()
        self.dbhelper.add_student(name, gender, num, grade, classno)

class InputScoreWindow(QtWidgets.QDialog, Ui_InputScoreDialog):
    def __init__(self):
        # init UI classes
        QtWidgets.QMainWindow.__init__(self)
        Ui_InputScoreDialog.__init__(self)
        self.setupUi(self)
        # set fixed size
        self.setFixedSize(self.size())
        # set window title
        self.title = self.setWindowTitle("学生成绩输入")
        # link objects with widgets
        self.connect_object()

    def connect_object(self):
        self.resetButton.clicked.connect(self.reset_dialog_text)
        self.addButton.clicked.connect(self.add_score)

    def reset_dialog_text(self):
        self.numEdit.clear()
        self.chineseEdit.clear()
        self.mathEdit.clear()
        self.englishEdit.clear()
        self.sportsEdit.clear()

    def add_score(self):
        num = int(self.numEdit.text())
        chinese = int(self.chineseEdit.text())
        math = int(self.mathEdit.text())
        english = int(self.englishEdit.text())
        sports = int(self.sportsEdit.text())
        self.dbhelper = DBHelper()
        self.dbhelper.add_score(num, chinese, math, english, sports)

class ShowStudentWindow(QtWidgets.QDialog, Ui_ShowDialog):
    def __init__(self):
        # init UI classes
        QtWidgets.QMainWindow.__init__(self)
        Ui_ShowDialog.__init__(self)
        self.setupUi(self)
        # set fixed size
        self.setFixedSize(self.size())
        # set window title
        self.title = self.setWindowTitle("学生信息显示")
        # set up table
        self.showTable.setRowCount(0)
        self.showTable.setColumnCount(5)
        self.showTable.horizontalHeader().setStretchLastSection(True)
        self.showTable.verticalHeader().setVisible(False)
        self.showTable.setHorizontalHeaderLabels(['姓名', '性别', '学号', '年级', '班级'])
        # show
        self.dbhelper = DBHelper()
        self.dbhelper.show_student()
        self.show_student_content()

    def show_student_content(self):
        self.showTable.setRowCount(len(self.dbhelper.list))
        for num_rows in range(len(self.dbhelper.list)):
            for num_columns in range(len(self.dbhelper.list[num_rows])):
                current_item = QtWidgets.QTableWidgetItem(str(self.dbhelper.list[num_rows][num_columns]))
                self.showTable.setItem(num_rows, num_columns, current_item)

class ShowScoreWindow(QtWidgets.QDialog, Ui_ShowDialog):
    def __init__(self):
        # init UI classes
        QtWidgets.QMainWindow.__init__(self)
        Ui_ShowDialog.__init__(self)
        self.setupUi(self)
        # set fixed size
        self.setFixedSize(self.size())
        # set window title
        self.title = self.setWindowTitle("学生成绩显示")
        # set up table
        self.showTable.setRowCount(0)
        self.showTable.setColumnCount(9)
        self.showTable.horizontalHeader().setStretchLastSection(True)
        self.showTable.verticalHeader().setVisible(False)
        self.showTable.setHorizontalHeaderLabels(['姓名', '性别', '学号', '年级', '班级', '语文', '数学', '外语', '体育'])
        # show
        self.dbhelper = DBHelper()
        self.dbhelper.show_score()
        self.show_score_content()

    def show_score_content(self):
        self.showTable.setRowCount(len(self.dbhelper.list))
        for num_rows in range(len(self.dbhelper.list)):
            for num_columns in range(len(self.dbhelper.list[num_rows])):
                current_item = QtWidgets.QTableWidgetItem(str(self.dbhelper.list[num_rows][num_columns]))
                self.showTable.setItem(num_rows, num_columns, current_item)

if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    main_window = StudentMainWindow()
    main_window.show()
    sys.exit(app.exec_())
