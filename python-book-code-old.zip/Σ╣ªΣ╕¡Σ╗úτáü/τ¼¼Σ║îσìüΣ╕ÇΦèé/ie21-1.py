#实例21-1
score=(95,93,98,82,95,86,88,96,90,89)
maxscore,*mscore,minscore=sorted(score,reverse=True)
A_score=sum(mscore)/len(mscore)
print("A选手的最终得分：{:.2f}分".format(A_score))
