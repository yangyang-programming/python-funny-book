#实例13-2
for i in range(5):
    print("hello")
