#ie32-2.py
class Stack:
    def __init__(self):
        self.stack = []

    def add(self, val):
        self.stack.append(val)
        return True
      
    def remove(self):
        if len(self.stack) <= 0:
            return ("空栈")
        else:
            return self.stack.pop()

AStack = Stack()
s=eval(input("输入一个十进制数："))
while (s!=0):
    y=s%8
    s=s//8    
    AStack.add(y)
print("八进制数为：")
while(len(AStack.stack)>0):
    print(AStack.remove(),end="")

