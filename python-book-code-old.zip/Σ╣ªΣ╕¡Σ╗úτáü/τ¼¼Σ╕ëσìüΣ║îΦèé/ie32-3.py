#ie32-3.py
class Queue:
    def __init__(self):
        self.queue = list()

    def addtoq(self,val):
        if val not in self.queue:
            self.queue.insert(0,val)
            return True
        return False

    def size(self):
        return len(self.queue)

MyQueue = Queue()
MyQueue.addtoq("1")
MyQueue.addtoq("2")
MyQueue.addtoq("3")
MyQueue.addtoq("4")
print("队列共有元素："+str(MyQueue.size()))
for i in MyQueue.queue:
    print(i)
