#练习1
a=123.5
b=300
c="Tom"
print("{:08d}".format(b))
print("{:.3f}".format(a))
print("{:+^10}".format(c))
