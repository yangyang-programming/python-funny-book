#ie31-1.py
class Node:
    def __init__(self, val=None):
        self.val = val
        self.nextval = None

class SLinkedList:
    def __init__(self):
        self.headval = None

LinkL1 = SLinkedList()
LinkL1.headval = Node("1")
e2 = Node("2")
e3 = Node("3")
LinkL1.headval.nextval = e2
e2.nextval = e3
#LinkL1.listprint()
