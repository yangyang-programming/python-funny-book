#实例22-1
mystr=input("请任意输入一个字符串：")
if mystr[::-1]==mystr:
    print("{}是回文".format(mystr))
else:
    print("{}不是回文".format(mystr))
