#实例22-2 进一步修改版，考虑了多个单词长度相等的情况
mystr=input("请输入一句英文，单词间用空格间隔：")
mytab=mystr.split(" ")  #转换成单词列表
newtab=[]
for i in mytab:
    if i.isalnum()==False:#如果单词中含有符号把符号去掉
        for j in ",.?!%()&*@#$%':;":     
            i=i.strip(j)
    if i.isdigit()==True:#如果单词全是数字，则忽略，高为空
        i=""
    newtab.append(i) #规范后形成新的单词列表
    

result=sorted(newtab,key=lambda i:len(i),reverse=True)#将单词列表按长度降序排列
newresult=[]  #用于存储新列表各单词长度，找出最大长度单词的个数
for i in result:  
    newresult.append(len(i))

for x in range(newresult.count(newresult[0])):#newresult.count(newresult[0])计算了最长单词的个数
    print("{} {}".format(result[x],len(result[x])))
