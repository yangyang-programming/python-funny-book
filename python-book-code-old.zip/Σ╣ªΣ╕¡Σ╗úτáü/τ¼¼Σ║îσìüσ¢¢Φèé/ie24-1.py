#实例24-1
alpha=dict()
alpha=alpha.fromkeys(list("abcdefghijklmnopqrstuvwxyz"),0)  #建立以字母为键的字典
x=input("请输入一句英语：")
for i in x:   #一个一个字母的遍历
    i=i.lower()  #将字母统一转为小写
    if i in alpha:  #将i转为小写，判断是不是字母，比如hello world，如果i是中间的空格则跳过
        alpha[i]=alpha[i]+1
for i in alpha:
    if alpha[i]!=0:
        print("{}:{}个".format(i,alpha[i]))
