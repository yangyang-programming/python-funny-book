#实例23-1
article=input("请输入一段英文：")
for i in '''",.;:'?/[]{}!@#$%^&*()''':
    article=article.replace(i,"")

word_list=article.split(" ")
word_set=set(word_list)
for i in word_set:
    print("{}:{}".format(i,word_list.count(i)))
