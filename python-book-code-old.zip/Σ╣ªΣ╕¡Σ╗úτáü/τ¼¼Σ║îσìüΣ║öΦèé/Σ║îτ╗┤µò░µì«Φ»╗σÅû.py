f=open("人口.csv","r")
mydate=[]
for row in f:
    mydate.append(row.strip("\n").split(","))
print(mydate)
f.close()
