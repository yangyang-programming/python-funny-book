#一维数据的写入
mydate=["天安门","故宫","颐和园","长城"]
f=open("space.csv","w")
f.write(",".join(mydate)+"\n")
f.close()
