#ie36-3.py
import random
def bsearch(arr, val):
    x=0  #记录找的次数
    list_size = len(arr) - 1
    idx0 = 0
    idxn = list_size
    while idx0 <= idxn:
         x+=1
         midval = (idx0 + idxn)//2
         if arr[midval] == val:
             return x  #返回一共找了多少次
         if val > arr[midval]:
             idx0 = midval + 1
         else:
             idxn = midval - 1

    if idx0 > idxn:
         return None


my_int=random.randint(0,10000)
print(my_int)
num=bsearch(list(range(0,10000)),my_int)
print(num)
