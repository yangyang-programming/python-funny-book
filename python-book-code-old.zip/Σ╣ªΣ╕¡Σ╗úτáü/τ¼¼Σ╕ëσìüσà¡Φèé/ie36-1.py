#ie36-1.py
import random
my_int=random.randint(0,10000)
input_int=-1
x=0
while(input_int!=my_int):
    input_int="w"
    while(type(input_int)!=type(1)):
        try:
            input_int=int(input("请输入一个整数（0—10000）："))
        except:
            pass
    if(input_int>my_int):
        print("猜大了")
    if(input_int<my_int):
        print("猜小了")
    x+=1
print("恭喜你猜对了,一共猜了%d次"%x)
