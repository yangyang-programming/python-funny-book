#ie41-1.py
import sqlite3
from sqlite3 import Error

def create_connection(db_file):
    try:
        conn = sqlite3.connect(db_file)
        return conn
    except Error as e:
        print(e)
    return None

def select_all_student(conn):
    cur = conn.cursor()
    cur.execute("SELECT * FROM student")
    rows = cur.fetchall()
    for row in rows:
        print(row)

def main():
    database = "score.db"

    conn = create_connection(database)
    if conn is not None:
        select_all_student(conn)
    conn.close()

if __name__ == '__main__':
    main()
